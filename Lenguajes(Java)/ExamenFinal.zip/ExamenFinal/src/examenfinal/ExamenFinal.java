/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examenfinal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author dante
 */

public class ExamenFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         // TODO add your handling code here:
    String jdbcUrl = "jdbc:mariadb://localhost:3306/prueba01";
    String username = "root";
    String password = "";
    Connection conn = null;
    Statement stmt = null;

    try {
      //Open connection
      conn = DriverManager.getConnection(jdbcUrl, username, password);
      
      //Create statement
      stmt = conn.createStatement();
      //stmt = conn.createStatement();
      String record1="UPDATE `inventario` SET `Inventario`='4' WHERE ID = '1'";
      stmt.executeUpdate(record1);
      
         System.out.println("Records inserted");
        
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      try {
        // Close connection
        if (stmt != null) {
          stmt.close();
        }
        if (conn != null) {
          conn.close();
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
 

    }
}
