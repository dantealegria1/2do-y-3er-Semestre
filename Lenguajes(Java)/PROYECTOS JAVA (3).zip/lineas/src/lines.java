import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class lines extends JPanel implements ActionListener {
    TextField name;
    int oportunidades=0;
    Image img;

   // Creating a new text field and adding an action listener to it.
    public lines()
    {
        String imageFile="D:\\dante\\Downloads\\kirby-dance.gif";
  // Getting the image from the file.
        img=Toolkit.getDefaultToolkit().getImage(imageFile);
        name=new TextField(20);
        name.addActionListener(this);
        add(name);
    }/**
     * The function is called when the user clicks on the button. It increments the number of chances
     * the user has had to guess the word. It then repaints the screen to show the new number of
     * chances. If the user has had 5 chances, it displays a message saying that the user has lost and
     * exits the program
     * 
     * @param ae The ActionEvent object that was generated when the user clicked the button.
     */
    
    public void actionPerformed(ActionEvent ae)
    {
        oportunidades++;
        repaint();
        if(oportunidades==5)
        {
            JOptionPane.showMessageDialog(null,"You have lost");
            System.exit(0);
        }
    }
    public void paintComponents(Graphics g)
    {
       // Drawing a line.
       g.setColor(Color.red);
        super.paintComponents(g);
        if(oportunidades==1)
        {
           // Drawing a line from the point (100,110) to the point (140,150).
            g.drawLine(100,110,140,150);
        }
        if(oportunidades==2)
        {
            g.drawLine(100,110,140,150);
            g.drawOval(100,110,140,150);
        }
        if(oportunidades==3)
        {
            g.drawLine(100,110,140,150);
            g.drawOval(100,110,140,150);
            g.drawString("prueba",50,50);
        }
        if(oportunidades==4)
        {
            g.drawLine(100,110,140,150);
            g.drawOval(100,110,140,150);
            g.drawString("prueba",50,50);
            g.drawImage(img,120,140,55,55,this);
        }

      
    }
    public static void main(String args[])
    {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame=new JFrame("Lines");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new lines());
        frame.setBounds(100,100,400,325);
        frame.setVisible(true);
    }
}