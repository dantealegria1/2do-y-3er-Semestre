import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
public class Almacen {
    static public void main(String[] args)
    {
        int arreglo[]={4,3,3,2};
        try
        {
            OutputStream out = new FileOutputStream("hola2.txt");
            for(int i=0;i< arreglo.length;i++)
            {
                out.write(arreglo[i]);
            }
            out.close();
        
        InputStream file=new FileInputStream("hola2.txt");
        int size=file.available();
        for(int i=0;i<size;i++)
        {
            System.out.println(file.read()+" ");
        }
        file.close();
        out.close();
    }
    catch(IOException e)
    {
        System.out.println("Error");
    }
    }
}